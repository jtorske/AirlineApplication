/*
@author 
Chun Lok Chan
Jordan Torske
Logan Nightingale
Mohamad Hussein
@version: 1.0
@since: 2023-11-23
*/

package Domains.Seats;

public interface Seat {
    //Returns a string containing the Seat number, row and column. E.g. 1A2
    public String Display();
    public boolean booked();
    public double GetPrice();
    public void Book();
    public int getRow();
    public char getColumn();
}
